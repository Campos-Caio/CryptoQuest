import firebase_admin.auth
from app.core.firebase import get_firestore_db 
from app.repositories.user_repository import UserRepository 
from app.models.user import UserProfile, FirebaseUser, UserRegister
from firebase_admin.auth import UserNotFoundError, InvalidIdTokenError, EmailAlreadyExistsError

class AuthService: 
    def __init__(self, user_repo: UserRepository):
        self.auth = get_firestore_db() 
        self.user_repo = user_repo 

    async def register_user(self, user_data: UserRegister) -> tuple[FirebaseUser, UserProfile]: 
        """
            Cria um novo usuario no Firebase Auth e seu perfil no Firestore 
        """

        try: 
            # 1. Criar Usuario no Firebase Auth
            user = self.auth.create_user(
                email = user_data.email,
                password = user_data.password, 
                display_name = user_data.name 
            )

            # 2. Criar perfil no Firestore usando o UID do usuario 
            user_profile = await self.user_repo.create_user_profile(
                uid=user.uid, 
                name = user_data.name, 
                email = user_data.email 
            )
            firebase_user_info = FirebaseUser(uid=user.uid, email=user.email, name=user.name)
            return firebase_user_info, user_profile
        except firebase_admin.auth.AuthError as error: 
            # Verifica se o erro é um erro de senha
            if error.code == 'auth/weak-password':
                raise ValueError("Senha muito fraca. Minimo de 6 caracteres.")
            # Tratamento de outros erros de autenticação
            elif error.code == 'auth/email-already-exists':
                raise ValueError("Email já cadastrado!")
            # Tratamento de outros erros
            else:
                raise ValueError(f"Erro inesperado! Erro: {error}")
        

    async def verify_id_token(self, id_token: str) -> FirebaseUser: 
        """
            Verifica e decodifica o token de ID do Firebase
        """ 

        try: 
            decoded_token = self.auth.verify_id_token(id_token)

            return FirebaseUser(
                uid = decoded_token['uid'], 
                email=decoded_token['email'], 
                name = decoded_token.get('name')
            )
        
        except InvalidIdTokenError: 
            raise ValueError("Token de ID invalido ou expirado!")
        except Exception as error: 
            raise Exception (f"Erro inesperado! Erro: {error}")
        
async def get_auth_service():
    return AuthService() 